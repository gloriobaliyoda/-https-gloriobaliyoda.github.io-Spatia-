import { type Express } from "express";
import * as expressStatic from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { planLimits, subscriptionPlans } from "@shared/schema";
import { convert2DTo3D, generateModelDescription } from "./services/openai";
import { intelligentConversion } from "./services/enhanced-conversion";
import { log } from "./vite";

// Set up multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
});

// Ensure directories exist for storing files
const UPLOAD_DIR = path.join(process.cwd(), "public");
const MODELS_DIR = path.join(UPLOAD_DIR, "models");
const THUMBNAILS_DIR = path.join(UPLOAD_DIR, "thumbnails");

// Create directories if they don't exist
[UPLOAD_DIR, MODELS_DIR, THUMBNAILS_DIR].forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  
  // Serve static files from public directory
  app.use('/models', (req, res, next) => {
    expressStatic.static(MODELS_DIR)(req, res, next);
  });
  app.use('/thumbnails', (req, res, next) => {
    expressStatic.static(THUMBNAILS_DIR)(req, res, next);
  });

  // API routes
  app.get("/api/projects", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const projects = await storage.getProjects(req.user.id);
    res.json(projects);
  });

  app.get("/api/projects/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const project = await storage.getProject(parseInt(req.params.id));
    if (!project) return res.status(404).send("Project not found");
    if (project.userId !== req.user.id) return res.sendStatus(403);
    
    res.json(project);
  });

  // Create a project (metadata only)
  app.post("/api/projects", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const user = req.user;
    
    // Check if user exceeds conversion limit
    if (user.plan === subscriptionPlans.FREE_TRIAL && user.conversionsUsed >= planLimits[subscriptionPlans.FREE_TRIAL]) {
      return res.status(403).json({ 
        message: "You have reached your free trial limit. Please upgrade to continue." 
      });
    }
    
    // For paid plans, check daily limit
    const userProjects = await storage.getProjects(user.id);
    const todayProjects = userProjects.filter(p => {
      const projectDate = new Date(p.createdAt);
      const today = new Date();
      return projectDate.getDate() === today.getDate() && 
             projectDate.getMonth() === today.getMonth() && 
             projectDate.getFullYear() === today.getFullYear();
    });
    
    if (user.plan !== subscriptionPlans.FREE_TRIAL && todayProjects.length >= planLimits[user.plan]) {
      return res.status(403).json({ 
        message: "You have reached your daily conversion limit. Please try again tomorrow." 
      });
    }
    
    try {
      // Create project
      const project = await storage.createProject({
        ...req.body,
        userId: user.id
      });
      
      res.status(201).json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to create project", error });
    }
  });
  
  // Upload and process a 2D layout file
  app.post("/api/projects/:id/upload", upload.single('file'), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    if (!req.file) return res.status(400).json({ message: "No file uploaded" });
    
    const projectId = parseInt(req.params.id);
    const user = req.user;
    
    try {
      // Get project and verify ownership
      const project = await storage.getProject(projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });
      if (project.userId !== user.id) return res.sendStatus(403);
      
      // Update project status to 'processing'
      await storage.updateProjectStatus(projectId, 'processing');
      
      // Get file information
      const fileBuffer = req.file.buffer;
      const fileType = req.file.originalname.split('.').pop() || '';
      
      log(`Processing file upload for project ${projectId}`, "projects");
      
      // Start the conversion process (non-blocking)
      (async () => {
        try {
          // Generate description using OpenAI (or mock in development)
          const description = await generateModelDescription(fileBuffer, fileType);
          log(`Generated description for project ${projectId}: ${description.substring(0, 100)}...`, "projects");
          
          // Convert 2D to 3D using our enhanced conversion pipeline
          const result = await intelligentConversion(fileBuffer, req.file?.originalname || `unknown.${fileType}`, {
            quality: "high",
            animate: true,
            animationDuration: 30,
            detailLevel: "high",
            realismLevel: 9
          });
          
          const { modelUrl, thumbnailUrl } = result;
          log(`Generated model URLs: ${modelUrl}, ${thumbnailUrl}`, "projects");
          
          // Save model and thumbnail paths
          await storage.updateProjectFiles(projectId, modelUrl, thumbnailUrl);
          
          // Update project status to 'completed'
          await storage.updateProjectStatus(projectId, 'completed');
          
          // Increment user's conversion count
          await storage.incrementUserConversions(user.id);
          
          log(`Conversion completed for project ${projectId}`, "projects");
        } catch (error) {
          log(`Error processing project ${projectId}: ${error}`, "projects");
          await storage.updateProjectStatus(projectId, 'failed');
        }
      })();
      
      // Return immediately with processing status
      res.json({ 
        message: "File uploaded successfully. Processing started.",
        status: "processing",
        projectId
      });
    } catch (error) {
      log(`Error in upload endpoint: ${error}`, "projects");
      res.status(500).json({ 
        message: "Failed to process file", 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.post("/api/subscribe", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const { plan } = req.body;
    if (!Object.values(subscriptionPlans).includes(plan)) {
      return res.status(400).json({ message: "Invalid subscription plan" });
    }
    
    // Simplified payment handling without Stripe
    try {
      // In a real app, you would process payment confirmation here
      // For this demo, we're simulating a successful payment
      log(`User ${req.user.username} subscribed to plan: ${plan}`, "subscriptions");
      
      // Update the user's plan
      const updatedUser = await storage.updateUserPlan(req.user.id, plan);
      
      // Return the updated user data
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update subscription", error });
    }
  });
  
  // Add an endpoint to simulate payment confirmation
  app.post("/api/payment-simulation", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const { plan, transactionId } = req.body;
    
    if (!plan || !transactionId) {
      return res.status(400).json({ message: "Missing required payment information" });
    }
    
    try {
      // Simulate payment verification process
      log(`Verifying payment ${transactionId} for plan ${plan}`, "payments");
      
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Update the user's plan
      const updatedUser = await storage.updateUserPlan(req.user.id, plan);
      
      res.json({
        success: true,
        message: "Payment verified successfully",
        user: updatedUser
      });
    } catch (error) {
      res.status(500).json({ 
        success: false,
        message: "Payment verification failed", 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
