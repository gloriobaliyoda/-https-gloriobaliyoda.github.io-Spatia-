import { users, projects, type User, type InsertUser, type Project, type InsertProject, subscriptionPlans } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPlan(id: number, plan: string): Promise<User | undefined>;
  incrementUserConversions(id: number): Promise<User | undefined>;
  
  getProjects(userId: number): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject & { userId: number }): Promise<Project>;
  updateProjectStatus(id: number, status: string): Promise<Project | undefined>;
  updateProjectFiles(id: number, modelFile: string, thumbnailFile: string): Promise<Project | undefined>;
  
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  sessionStore: session.Store;
  currentUserId: number;
  currentProjectId: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.currentUserId = 1;
    this.currentProjectId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
    
    // Create default admin user for testing
    // In production, this would be removed
    // Password: admin123
    const adminUser: User = {
      id: this.currentUserId++,
      username: "admin",
      email: "admin@spatiagenesis.com",
      password: "admin123", // Using plain password for admin in development
      plan: subscriptionPlans.FREE_TRIAL,
      conversionsUsed: 0,
      createdAt: new Date()
    };
    this.users.set(adminUser.id, adminUser);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      plan: subscriptionPlans.FREE_TRIAL,
      conversionsUsed: 0,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserPlan(id: number, plan: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, plan };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async incrementUserConversions(id: number): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, conversionsUsed: user.conversionsUsed + 1 };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getProjects(userId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(
      (project) => project.userId === userId,
    );
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject & { userId: number }): Promise<Project> {
    const id = this.currentProjectId++;
    const now = new Date();
    const project: Project = {
      ...insertProject,
      id,
      status: "processing",
      modelFile: null,
      thumbnailFile: null,
      createdAt: now,
      updatedAt: now,
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProjectStatus(id: number, status: string): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updatedProject = { ...project, status, updatedAt: new Date() };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async updateProjectFiles(id: number, modelFile: string, thumbnailFile: string): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updatedProject = { 
      ...project, 
      modelFile, 
      thumbnailFile, 
      status: "completed", 
      updatedAt: new Date()
    };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }
}

export const storage = new MemStorage();
