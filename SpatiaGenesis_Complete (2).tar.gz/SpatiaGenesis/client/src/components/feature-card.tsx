import { LucideIcon } from "lucide-react";

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  iconColor?: string;
  iconBgColor?: string;
}

export function FeatureCard({ 
  icon: Icon, 
  title, 
  description, 
  iconColor = "text-primary",
  iconBgColor = "bg-primary-50"
}: FeatureCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
      <div className={`w-12 h-12 flex items-center justify-center rounded-lg ${iconBgColor} ${iconColor} mb-4`}>
        <Icon className="h-5 w-5" />
      </div>
      <h3 className="font-semibold text-neutral-800 mb-2">{title}</h3>
      <p className="text-sm text-neutral-600">{description}</p>
    </div>
  );
}

export default FeatureCard;
