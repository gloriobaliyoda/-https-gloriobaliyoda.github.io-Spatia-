import { Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface UpgradeBannerProps {
  userPlan: string;
}

export function UpgradeBanner({ userPlan }: UpgradeBannerProps) {
  if (userPlan !== "free_trial") return null;

  return (
    <div className="bg-primary-50 border border-primary-100 rounded-lg p-4 mb-8 flex items-center justify-between">
      <div className="flex items-start space-x-3">
        <div className="text-primary mt-1">
          <Info className="h-5 w-5" />
        </div>
        <div>
          <h3 className="font-medium text-primary-800">You're on a Free Trial</h3>
          <p className="text-sm text-primary-600 mt-1">
            You can create one 3D model for free. Upgrade to continue creating amazing 3D models.
          </p>
        </div>
      </div>
      <Button className="shrink-0" asChild>
        <Link href="/subscription">
          <a>Upgrade Now</a>
        </Link>
      </Button>
    </div>
  );
}

export default UpgradeBanner;
