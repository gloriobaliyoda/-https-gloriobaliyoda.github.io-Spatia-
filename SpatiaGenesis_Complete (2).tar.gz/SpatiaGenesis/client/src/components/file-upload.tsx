import { useState, useRef } from "react";
import { Upload, File, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface FileUploadProps {
  onFileSelected: (file: File, name: string) => void;
  accept?: string;
  maxSize?: number; // in MB
}

export function FileUpload({ 
  onFileSelected, 
  accept = ".jpg,.jpeg,.png,.pdf,.svg,.dxf,.dwg", 
  maxSize = 50 
}: FileUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      processFile(files[0]);
    }
  };

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragOver(false);
    
    const files = event.dataTransfer.files;
    if (files && files.length > 0) {
      processFile(files[0]);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const processFile = (file: File) => {
    // Check file size
    const fileSizeMB = file.size / (1024 * 1024);
    if (fileSizeMB > maxSize) {
      toast({
        title: "File too large",
        description: `File size exceeds the maximum limit of ${maxSize}MB.`,
        variant: "destructive",
      });
      return;
    }

    // Check file type
    const fileType = file.type.toLowerCase();
    const acceptableTypes = accept.split(',').map(type => type.replace('.', ''));
    
    const isAcceptableType = acceptableTypes.some(type => {
      if (type === 'jpg') return fileType === 'image/jpeg';
      if (type === 'jpeg') return fileType === 'image/jpeg';
      if (type === 'png') return fileType === 'image/png';
      if (type === 'pdf') return fileType === 'application/pdf';
      if (type === 'svg') return fileType === 'image/svg+xml';
      if (type === 'dxf') return file.name.toLowerCase().endsWith('.dxf');
      if (type === 'dwg') return file.name.toLowerCase().endsWith('.dwg');
      return false;
    });

    if (!isAcceptableType) {
      toast({
        title: "Invalid file type",
        description: `Please upload a file with one of these extensions: ${accept}`,
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
    
    // Generate a name for the file based on the file type
    const fileExtension = file.name.split('.').pop()?.toLowerCase() || '';
    const timestamp = new Date().getTime();
    const fileName = `layout_${timestamp}.${fileExtension}`;
    
    onFileSelected(file, fileName);
  };

  return (
    <div
      className={`rounded-lg p-8 border-2 ${
        isDragOver 
          ? "border-primary bg-primary-50" 
          : selectedFile 
            ? "border-green-500 bg-green-50"
            : "border-dashed border-neutral-300 bg-neutral-50"
      } flex flex-col items-center justify-center text-center transition-colors`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {selectedFile ? (
        <div className="w-full">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <File className="h-8 w-8 text-green-500 mr-3" />
              <div className="text-left">
                <p className="font-medium text-neutral-700">{selectedFile.name}</p>
                <p className="text-xs text-neutral-500">
                  {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB
                </p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleRemoveFile}
              className="text-neutral-500 hover:text-red-500"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          <p className="text-sm text-green-600">File selected successfully!</p>
        </div>
      ) : (
        <>
          <div className="mb-4 text-neutral-400">
            <Upload className="h-12 w-12 mx-auto" />
          </div>
          <h3 className="text-lg font-medium text-neutral-700 mb-1">
            Drag & drop your 2D layout here
          </h3>
          <p className="text-sm text-neutral-500 mb-4">
            Supports JPG, PNG, PDF, SVG, DXF, DWG files up to {maxSize}MB
          </p>
          <Button onClick={handleButtonClick}>
            Select File
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept={accept}
            onChange={handleFileChange}
          />
        </>
      )}
    </div>
  );
}

export default FileUpload;
