import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Box, LayoutDashboard, FileText, Upload, Settings, HelpCircle, BookOpen, MoreVertical } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase();
  };

  const getNameFromUsername = (username: string) => {
    return username
      .split(/[._-]/)
      .map(part => part.charAt(0).toUpperCase() + part.slice(1))
      .join(' ');
  };

  return (
    <aside className="hidden md:flex md:w-64 flex-col bg-white border-r border-neutral-200">
      <div className="p-4 border-b border-neutral-200">
        <div className="flex items-center space-x-2">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="32" height="32">
            <rect x="40" y="40" width="120" height="120" fill="#3b82f6" rx="10" ry="10" />
            <path d="M40 100 L100 140 L160 100 L100 60 Z" fill="#2563eb" />
            <path d="M100 60 L160 100 L160 160 L100 120 Z" fill="#1d4ed8" />
            <path d="M40 100 L100 140 L100 200 L40 160 Z" fill="#1e40af" />
            <text x="100" y="110" fontFamily="Arial, sans-serif" fontSize="20" fontWeight="bold" fill="white" textAnchor="middle">S</text>
          </svg>
          <h1 className="text-xl font-semibold text-neutral-800">Spatia Genesis</h1>
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        <Link href="/">
          <a className={`flex items-center px-3 py-2 text-sm rounded-lg ${
            location === "/" 
              ? "bg-primary-50 text-primary font-medium" 
              : "text-neutral-600 hover:bg-neutral-100 font-medium"
          }`}>
            <LayoutDashboard className="mr-3 h-4 w-4" />
            <span>Dashboard</span>
          </a>
        </Link>
        <Link href="/projects">
          <a className={`flex items-center px-3 py-2 text-sm rounded-lg ${
            location === "/projects" 
              ? "bg-primary-50 text-primary font-medium" 
              : "text-neutral-600 hover:bg-neutral-100 font-medium"
          }`}>
            <FileText className="mr-3 h-4 w-4" />
            <span>My Projects</span>
          </a>
        </Link>
        <Link href="/new-conversion">
          <a className={`flex items-center px-3 py-2 text-sm rounded-lg ${
            location === "/new-conversion" 
              ? "bg-primary-50 text-primary font-medium" 
              : "text-neutral-600 hover:bg-neutral-100 font-medium"
          }`}>
            <Upload className="mr-3 h-4 w-4" />
            <span>New Conversion</span>
          </a>
        </Link>
        <Link href="/settings">
          <a className={`flex items-center px-3 py-2 text-sm rounded-lg ${
            location === "/settings" 
              ? "bg-primary-50 text-primary font-medium" 
              : "text-neutral-600 hover:bg-neutral-100 font-medium"
          }`}>
            <Settings className="mr-3 h-4 w-4" />
            <span>Settings</span>
          </a>
        </Link>
        
        <div className="pt-6">
          <div className="px-3 py-2 text-xs font-semibold text-neutral-400 uppercase">
            Resources
          </div>
          <a href="#" className="flex items-center px-3 py-2 text-sm rounded-lg text-neutral-600 hover:bg-neutral-100 font-medium">
            <HelpCircle className="mr-3 h-4 w-4" />
            <span>Help Center</span>
          </a>
          <a href="#" className="flex items-center px-3 py-2 text-sm rounded-lg text-neutral-600 hover:bg-neutral-100 font-medium">
            <BookOpen className="mr-3 h-4 w-4" />
            <span>Tutorials</span>
          </a>
        </div>
      </nav>
      
      <div className="p-4 border-t border-neutral-200">
        <div className="flex items-center space-x-3">
          <Avatar>
            <AvatarFallback>
              {user ? getInitials(user.username) : "?"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-neutral-800 truncate">
              {user ? getNameFromUsername(user.username) : "User"}
            </p>
            <p className="text-xs text-neutral-500 truncate">
              {user?.plan === "free_trial" ? "Free Trial" : user?.plan.replace('_', ' ')}
            </p>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="text-neutral-400 hover:text-neutral-600">
                <MoreVertical className="h-4 w-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild>
                <Link href="/settings">
                  <a className="cursor-pointer">Account Settings</a>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/subscription">
                  <a className="cursor-pointer">Subscription</a>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;
