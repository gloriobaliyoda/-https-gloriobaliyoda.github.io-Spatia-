import { useState } from "react";
import { Link } from "wouter";
import { Menu, Bell, ChevronDown, X } from "lucide-react";
import Sidebar from "./sidebar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState("EN");
  
  const languages = [
    { code: "EN", name: "English" },
    { code: "ES", name: "Español" },
    { code: "FR", name: "Français" },
    { code: "DE", name: "Deutsch" },
    { code: "ZH", name: "中文" },
  ];

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleLanguageChange = (langCode: string) => {
    setCurrentLanguage(langCode);
    // In a real app, you would implement language change logic here
  };

  return (
    <>
      <header className="bg-white border-b border-neutral-200">
        <div className="flex items-center justify-between px-4 h-16">
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="icon" 
              className="md:hidden" 
              onClick={toggleMobileMenu}
            >
              <Menu className="h-5 w-5 text-neutral-500" />
              <span className="sr-only">Toggle menu</span>
            </Button>
            <div className="md:hidden flex items-center space-x-2">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="28" height="28">
                <rect x="40" y="40" width="120" height="120" fill="#3b82f6" rx="10" ry="10" />
                <path d="M40 100 L100 140 L160 100 L100 60 Z" fill="#2563eb" />
                <path d="M100 60 L160 100 L160 160 L100 120 Z" fill="#1d4ed8" />
                <path d="M40 100 L100 140 L100 200 L40 160 Z" fill="#1e40af" />
                <text x="100" y="110" fontFamily="Arial, sans-serif" fontSize="20" fontWeight="bold" fill="white" textAnchor="middle">S</text>
              </svg>
              <h1 className="text-lg font-semibold text-neutral-800">Spatia Genesis</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="text-neutral-500">
              <Bell className="h-5 w-5" />
              <span className="sr-only">Notifications</span>
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="text-sm font-medium text-neutral-600 hover:text-neutral-800 flex items-center gap-1 h-8">
                  {currentLanguage}
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {languages.map((lang) => (
                  <DropdownMenuItem 
                    key={lang.code}
                    onClick={() => handleLanguageChange(lang.code)}
                    className="cursor-pointer"
                  >
                    {lang.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 md:hidden">
          <div className="flex flex-col bg-white h-full w-64">
            <div className="flex items-center justify-between p-4 border-b border-neutral-200">
              <div className="flex items-center space-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="32" height="32">
                  <rect x="40" y="40" width="120" height="120" fill="#3b82f6" rx="10" ry="10" />
                  <path d="M40 100 L100 140 L160 100 L100 60 Z" fill="#2563eb" />
                  <path d="M100 60 L160 100 L160 160 L100 120 Z" fill="#1d4ed8" />
                  <path d="M40 100 L100 140 L100 200 L40 160 Z" fill="#1e40af" />
                  <text x="100" y="110" fontFamily="Arial, sans-serif" fontSize="20" fontWeight="bold" fill="white" textAnchor="middle">S</text>
                </svg>
                <h1 className="text-xl font-semibold text-neutral-800">Spatia Genesis</h1>
              </div>
              <Button variant="ghost" size="icon" onClick={toggleMobileMenu}>
                <X className="h-5 w-5 text-neutral-500" />
              </Button>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              <Sidebar />
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default Navbar;
