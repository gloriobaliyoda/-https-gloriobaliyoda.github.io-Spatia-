import { useState } from "react";
import { CheckIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/use-auth";
import { subscriptionPlans } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import PaymentForm from "./payment-form";

interface SubscriptionCardProps {
  title: string;
  price: number;
  period: string;
  features: string[];
  popular?: boolean;
  savings?: string;
  planId: string;
}

export function SubscriptionCard({
  title,
  price,
  period,
  features,
  popular = false,
  savings,
  planId
}: SubscriptionCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const isCurrentPlan = user?.plan === planId;

  const handleSubscribe = () => {
    if (isCurrentPlan) {
      toast({
        title: "Already Subscribed",
        description: `You are already subscribed to the ${title} plan.`
      });
      return;
    }

    // Open payment dialog
    setPaymentDialogOpen(true);
  };

  return (
    <>
      <div 
        className={`bg-white rounded-xl shadow-sm 
          ${popular 
            ? "border-2 border-primary overflow-hidden relative" 
            : "border border-neutral-200 overflow-hidden"
          }`
        }
      >
        {popular && (
          <div className="absolute top-0 right-0 bg-primary text-white text-xs font-medium py-1 px-3 rounded-bl-lg">
            Most Popular
          </div>
        )}

        <div className="p-6">
          <h3 className="text-lg font-semibold text-neutral-800 mb-2">{title}</h3>
          <div className="flex items-baseline mb-4">
            <span className="text-3xl font-bold text-neutral-800">${price}</span>
            <span className="text-sm text-neutral-500 ml-1">/{period}</span>
          </div>

          {savings && (
            <div className="mb-4 rounded-lg bg-green-50 py-1 px-2 inline-flex items-center">
              <svg
                className="text-green-600 mr-1"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 2v8"/>
                <path d="m8.8 7.2 6.4 6.4"/>
                <path d="M19 7a7 7 0 1 1-14 0"/>
                <path d="m9 16 3 3 3-3"/>
              </svg>
              <span className="text-xs font-medium text-green-600">{savings}</span>
            </div>
          )}

          <ul className="space-y-3 mb-6">
            {features.map((feature, index) => (
              <li key={index} className="flex items-start">
                <CheckIcon className="h-4 w-4 text-green-500 mt-0.5 mr-2" />
                <span className="text-sm text-neutral-600">{feature}</span>
              </li>
            ))}
          </ul>

          <Button 
            className="w-full" 
            onClick={handleSubscribe}
            disabled={isCurrentPlan}
          >
            {isCurrentPlan 
              ? "Current Plan" 
              : "Subscribe Now"
            }
          </Button>
        </div>
      </div>

      {/* Payment Dialog */}
      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Subscribe to {title} Plan</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <PaymentForm 
              planId={planId} 
              price={price} 
              title={title} 
              onSuccess={() => setPaymentDialogOpen(false)}
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default SubscriptionCard;
