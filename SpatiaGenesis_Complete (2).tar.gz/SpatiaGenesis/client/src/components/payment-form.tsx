import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CreditCard, CheckCircle } from "lucide-react";

interface PaymentFormProps {
  planId: string;
  price: number;
  title: string;
  onSuccess?: () => void;
}

export function PaymentForm({ planId, price, title, onSuccess }: PaymentFormProps) {
  const { toast } = useToast();
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [name, setName] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);

  const paymentMutation = useMutation({
    mutationFn: async () => {
      // Generate a unique transaction ID
      const transactionId = `txn_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
      
      const response = await apiRequest("POST", "/api/payment-simulation", {
        plan: planId,
        transactionId,
        amount: price
      });
      
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/user"], data.user);
      setShowSuccess(true);
      
      toast({
        title: "Payment Successful",
        description: `You have been upgraded to the ${title} plan!`,
      });
      
      if (onSuccess) {
        onSuccess();
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!cardNumber || !expiryDate || !cvv || !name) {
      toast({
        title: "Missing Information",
        description: "Please fill in all payment details",
        variant: "destructive",
      });
      return;
    }
    
    paymentMutation.mutate();
  };

  const formatCardNumber = (input: string) => {
    const numbers = input.replace(/\D/g, '');
    const groups = [];
    
    for (let i = 0; i < numbers.length; i += 4) {
      groups.push(numbers.slice(i, i + 4));
    }
    
    return groups.join(' ').slice(0, 19);
  };

  const formatExpiryDate = (input: string) => {
    const numbers = input.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    return `${numbers.slice(0, 2)}/${numbers.slice(2, 4)}`;
  };

  if (showSuccess) {
    return (
      <div className="text-center py-8">
        <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="h-8 w-8 text-green-600" />
        </div>
        <h3 className="text-xl font-semibold text-neutral-800 mb-2">Payment Successful!</h3>
        <p className="text-neutral-600 mb-6">Your subscription has been upgraded to the {title} plan.</p>
        <Button onClick={() => setShowSuccess(false)}>Return to Subscription</Button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Cardholder Name</Label>
        <Input
          id="name"
          placeholder="John Doe"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      
      <div>
        <Label htmlFor="cardNumber">Card Number</Label>
        <div className="relative">
          <Input
            id="cardNumber"
            placeholder="4242 4242 4242 4242"
            value={cardNumber}
            onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
            maxLength={19}
          />
          <CreditCard className="absolute right-3 top-1/2 transform -translate-y-1/2 text-neutral-400" size={18} />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="expiryDate">Expiry Date</Label>
          <Input
            id="expiryDate"
            placeholder="MM/YY"
            value={expiryDate}
            onChange={(e) => setExpiryDate(formatExpiryDate(e.target.value))}
            maxLength={5}
          />
        </div>
        <div>
          <Label htmlFor="cvv">CVV</Label>
          <Input
            id="cvv"
            placeholder="123"
            value={cvv}
            onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 3))}
            maxLength={3}
            type="password"
          />
        </div>
      </div>
      
      <div className="pt-4">
        <Button
          type="submit"
          className="w-full"
          disabled={paymentMutation.isPending}
        >
          {paymentMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            `Pay $${price}`
          )}
        </Button>
      </div>
      
      <div className="text-center text-xs text-neutral-500 pt-2">
        <p>This is a simulated payment form for demonstration purposes.</p>
        <p>No actual payment will be processed.</p>
      </div>
    </form>
  );
}

export default PaymentForm;