import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { Loader2 } from 'lucide-react';

interface ModelViewerProps {
  modelUrl?: string;
  className?: string;
  isProcessing?: boolean;
  progress?: number;
}

export function ModelViewer({ 
  modelUrl, 
  className = '', 
  isProcessing = false,
  progress = 0
}: ModelViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const frameIdRef = useRef<number | null>(null);

  // Initialize Three.js scene
  useEffect(() => {
    if (!containerRef.current) return;

    // Create scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1E293B);
    sceneRef.current = scene;

    // Create camera
    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.z = 5;
    cameraRef.current = camera;

    // Create renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Add grid helper
    const gridHelper = new THREE.GridHelper(10, 10, 0x404040, 0x404040);
    scene.add(gridHelper);

    // Add controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controlsRef.current = controls;

    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    // Add directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);

    // Animation loop
    const animate = () => {
      frameIdRef.current = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Handle window resize
    const handleResize = () => {
      if (!containerRef.current || !cameraRef.current || !rendererRef.current) return;
      
      cameraRef.current.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (frameIdRef.current) {
        cancelAnimationFrame(frameIdRef.current);
      }
      if (rendererRef.current && containerRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement);
      }
      rendererRef.current?.dispose();
    };
  }, []);

  // Load 3D model when URL changes
  useEffect(() => {
    if (!modelUrl || !sceneRef.current) return;

    // Remove any existing models
    if (sceneRef.current) {
      const modelsToRemove = sceneRef.current.children.filter(
        child => child instanceof THREE.Group || child instanceof THREE.Mesh
      );
      modelsToRemove.forEach(model => sceneRef.current?.remove(model));
    }

    // Load new model
    const loader = new GLTFLoader();
    loader.load(
      modelUrl,
      (gltf) => {
        if (sceneRef.current) {
          sceneRef.current.add(gltf.scene);
          
          // Center the model
          const box = new THREE.Box3().setFromObject(gltf.scene);
          const center = box.getCenter(new THREE.Vector3());
          gltf.scene.position.sub(center);
          
          // Scale the model to fit the view
          const size = box.getSize(new THREE.Vector3());
          const maxDim = Math.max(size.x, size.y, size.z);
          if (maxDim > 0) {
            const scale = 4 / maxDim;
            gltf.scene.scale.set(scale, scale, scale);
          }
        }
      },
      undefined,
      (error) => {
        console.error('Error loading 3D model:', error);
      }
    );
  }, [modelUrl]);

  // When no model is available or model is processing, display a placeholder
  if (isProcessing) {
    return (
      <div className={`aspect-video relative bg-neutral-800 ${className}`}>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mb-3">
            <Loader2 className="text-primary h-6 w-6 animate-spin" />
          </div>
          <p className="text-sm text-neutral-300 font-medium">Processing</p>
          <div className="mt-3 w-3/4 max-w-xs">
            <div className="w-full h-2 bg-neutral-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary transition-all duration-300" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!modelUrl) {
    return (
      <div className={`aspect-video relative bg-neutral-800 ${className}`}>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-white/50 text-center">
            <svg
              className="mx-auto h-12 w-12 mb-4"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M20 7l-8-4-8 4v10l8 4 8-4V7z"
              />
            </svg>
            <p className="text-neutral-400">No 3D model to display</p>
          </div>
        </div>
      </div>
    );
  }

  return <div ref={containerRef} className={`aspect-video ${className}`}></div>;
}

export default ModelViewer;
