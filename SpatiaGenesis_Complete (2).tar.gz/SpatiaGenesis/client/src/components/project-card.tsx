import { Link } from "wouter";
import { Download, MoreVertical, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatDistanceToNow } from "date-fns";
import { Project } from "@shared/schema";

interface ProjectCardProps {
  project: Project;
  onDelete?: (projectId: number) => void;
}

export function ProjectCard({ project, onDelete }: ProjectCardProps) {
  const isCompleted = project.status === "completed";
  const isProcessing = project.status === "processing";
  const isFailed = project.status === "failed";

  const getStatusColor = () => {
    if (isCompleted) return "bg-green-50 text-green-600";
    if (isProcessing) return "bg-blue-50 text-blue-600";
    if (isFailed) return "bg-red-50 text-red-600";
    return "bg-neutral-50 text-neutral-600";
  };

  const getStatusText = () => {
    if (isCompleted) return "Completed";
    if (isProcessing) return "In Progress";
    if (isFailed) return "Failed";
    return project.status;
  };

  const formattedDate = formatDistanceToNow(new Date(project.createdAt), { addSuffix: true });

  return (
    <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden hover:shadow-md transition">
      <div className="aspect-video relative bg-neutral-800">
        {isProcessing ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mb-3">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
            </div>
            <p className="text-sm text-neutral-300 font-medium">Processing</p>
          </div>
        ) : isCompleted && project.modelFile ? (
          <Link href={`/view-project/${project.id}`}>
            <a className="block absolute inset-0">
              {project.thumbnailFile ? (
                <img 
                  src={project.thumbnailFile} 
                  alt={project.name} 
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-white/50">
                    <svg className="h-16 w-16" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M21 16.5c0 .38-.21.71-.53.88l-7.9 4.44c-.16.12-.36.18-.57.18s-.41-.06-.57-.18l-7.9-4.44A.991.991 0 0 1 3 16.5v-9c0-.38.21-.71.53-.88l7.9-4.44c.16-.12.36-.18.57-.18s.41.06.57.18l7.9 4.44c.32.17.53.5.53.88v9zM12 4.15L5 8.09v7.82l7 3.94 7-3.94V8.09l-7-3.94z"/>
                    </svg>
                  </div>
                </div>
              )}
            </a>
          </Link>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-white/50">
              <svg className="h-16 w-16" fill="currentColor" viewBox="0 0 24 24">
                <path d="M21 16.5c0 .38-.21.71-.53.88l-7.9 4.44c-.16.12-.36.18-.57.18s-.41-.06-.57-.18l-7.9-4.44A.991.991 0 0 1 3 16.5v-9c0-.38.21-.71.53-.88l7.9-4.44c.16-.12.36-.18.57-.18s.41.06.57.18l7.9 4.44c.32.17.53.5.53.88v9zM12 4.15L5 8.09v7.82l7 3.94 7-3.94V8.09l-7-3.94z"/>
              </svg>
            </div>
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-medium text-neutral-800 mb-1">{project.name}</h3>
        <p className="text-xs text-neutral-500 mb-3">{formattedDate}</p>
        <div className="flex items-center justify-between">
          <span className={`text-xs px-2 py-1 ${getStatusColor()} rounded-full font-medium`}>
            {getStatusText()}
          </span>
          <div className="flex space-x-2">
            {isCompleted && (
              <Button 
                variant="ghost" 
                size="icon"
                className="text-neutral-400 hover:text-neutral-600 hover:bg-neutral-100"
                asChild
              >
                <a href={project.modelFile || "#"} download>
                  <Download className="h-4 w-4" />
                </a>
              </Button>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="text-neutral-400 hover:text-neutral-600 hover:bg-neutral-100"
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href={`/view-project/${project.id}`}>
                    <a className="cursor-pointer">View Details</a>
                  </Link>
                </DropdownMenuItem>
                {onDelete && (
                  <DropdownMenuItem 
                    onClick={() => onDelete(project.id)}
                    className="text-red-500 focus:text-red-500 cursor-pointer"
                  >
                    Delete Project
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProjectCard;
