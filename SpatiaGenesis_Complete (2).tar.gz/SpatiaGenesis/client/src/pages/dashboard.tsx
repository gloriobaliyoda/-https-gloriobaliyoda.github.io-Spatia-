import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Project } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Brain, MessageSquare, Palette, Languages } from "lucide-react";
import Sidebar from "@/components/layout/sidebar";
import Navbar from "@/components/layout/navbar";
import ProjectCard from "@/components/project-card";
import FeatureCard from "@/components/feature-card";
import UpgradeBanner from "@/components/upgrade-banner";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { user } = useAuth();
  
  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  // Get the most recent projects (up to 3)
  const recentProjects = [...projects].sort((a, b) => {
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  }).slice(0, 3);

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        
        <main className="flex-1 overflow-auto p-4 md:p-6 bg-neutral-50">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-neutral-800">Welcome to Spatia</h1>
            <p className="text-neutral-600 mt-1">Transform your 2D layouts into stunning 3D models with AI</p>
          </div>
          
          {user && <UpgradeBanner userPlan={user.plan} />}
          
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 mb-8 overflow-hidden">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-neutral-800 mb-4">Start Creating</h2>
              <Button size="lg" className="w-full sm:w-auto" asChild>
                <Link href="/new-conversion">
                  <a>Create New 3D Model</a>
                </Link>
              </Button>
            </div>
          </div>
          
          <h2 className="text-xl font-semibold text-neutral-800 mb-4">Recent Projects</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {isLoading ? (
              Array(3).fill(0).map((_, index) => (
                <div key={index} className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden">
                  <div className="aspect-video bg-neutral-200 animate-pulse" />
                  <div className="p-4">
                    <div className="h-5 bg-neutral-200 rounded animate-pulse mb-2" />
                    <div className="h-4 bg-neutral-200 rounded animate-pulse w-1/3 mb-3" />
                    <div className="flex items-center justify-between">
                      <div className="h-6 bg-neutral-200 rounded animate-pulse w-1/4" />
                      <div className="h-8 bg-neutral-200 rounded animate-pulse w-1/6" />
                    </div>
                  </div>
                </div>
              ))
            ) : recentProjects.length > 0 ? (
              recentProjects.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))
            ) : (
              <div className="col-span-full text-center py-8">
                <p className="text-neutral-500">No projects yet. Create your first 3D model!</p>
                <Button className="mt-4" asChild>
                  <Link href="/new-conversion">
                    <a>Create New 3D Model</a>
                  </Link>
                </Button>
              </div>
            )}
          </div>
          
          {recentProjects.length > 0 && (
            <div className="mb-8 text-center">
              <Button variant="outline" asChild>
                <Link href="/projects">
                  <a>View All Projects</a>
                </Link>
              </Button>
            </div>
          )}
          
          <h2 className="text-xl font-semibold text-neutral-800 mb-4">Key Features</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <FeatureCard
              icon={Brain}
              title="AI-Powered Conversion"
              description="Transform any 2D layout into a detailed 3D model with our advanced AI technology."
              iconColor="text-primary"
              iconBgColor="bg-primary-50"
            />
            
            <FeatureCard
              icon={MessageSquare}
              title="Voice Commands"
              description="Control the app with your voice for a hands-free, intuitive experience."
              iconColor="text-blue-500"
              iconBgColor="bg-blue-50"
            />
            
            <FeatureCard
              icon={Palette}
              title="Advanced Editing"
              description="Fine-tune your 3D models with our comprehensive editing tools."
              iconColor="text-green-500"
              iconBgColor="bg-green-50"
            />
            
            <FeatureCard
              icon={Languages}
              title="Multi-language"
              description="Use Spatia in your preferred language with our multi-language support."
              iconColor="text-amber-500"
              iconBgColor="bg-amber-50"
            />
          </div>
        </main>
      </div>
    </div>
  );
}
