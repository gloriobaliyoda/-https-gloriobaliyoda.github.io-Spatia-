import { useEffect, useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Project } from "@shared/schema";
import { Download, ArrowLeft, Loader2 } from "lucide-react";
import Sidebar from "@/components/layout/sidebar";
import Navbar from "@/components/layout/navbar";
import ModelViewer from "@/components/model-viewer";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";

export default function ViewProject() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const [progress, setProgress] = useState(0);
  
  const { data: project, isLoading } = useQuery<Project>({
    queryKey: [`/api/projects/${id}`],
  });

  // Simulate progress for processing projects
  useEffect(() => {
    if (project?.status === "processing") {
      const interval = setInterval(() => {
        setProgress(prevProgress => {
          const newProgress = prevProgress + 5;
          if (newProgress >= 100) {
            clearInterval(interval);
            return 100;
          }
          return newProgress;
        });
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [project]);

  if (isLoading) {
    return (
      <div className="flex h-screen overflow-hidden">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          <Navbar />
          
          <main className="flex-1 overflow-auto p-4 md:p-6 bg-neutral-50 flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </main>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex h-screen overflow-hidden">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          <Navbar />
          
          <main className="flex-1 overflow-auto p-4 md:p-6 bg-neutral-50">
            <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6 text-center">
              <h1 className="text-xl font-semibold text-neutral-800 mb-4">Project Not Found</h1>
              <p className="text-neutral-600 mb-6">The project you're looking for doesn't exist or you don't have permission to view it.</p>
              <Button variant="outline" onClick={() => navigate("/projects")}>
                Back to Projects
              </Button>
            </div>
          </main>
        </div>
      </div>
    );
  }

  const formattedDate = formatDistanceToNow(new Date(project.createdAt), { addSuffix: true });
  const isProcessing = project.status === "processing";
  const isCompleted = project.status === "completed";

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        
        <main className="flex-1 overflow-auto p-4 md:p-6 bg-neutral-50">
          <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <Button 
                variant="ghost" 
                className="mb-2 -ml-2 text-neutral-600" 
                onClick={() => navigate("/projects")}
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                Back to Projects
              </Button>
              <h1 className="text-2xl font-bold text-neutral-800">{project.name}</h1>
              <p className="text-neutral-600 mt-1">Created {formattedDate}</p>
            </div>
            
            {isCompleted && project.modelFile && (
              <Button className="sm:self-start" asChild>
                <a href={project.modelFile} download>
                  <Download className="mr-2 h-4 w-4" />
                  Download 3D Model
                </a>
              </Button>
            )}
          </div>
          
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden mb-6">
            <ModelViewer 
              modelUrl={isCompleted ? project.modelFile || undefined : undefined}
              isProcessing={isProcessing}
              progress={progress}
              className="rounded-t-xl"
            />
            
            <div className="p-4 border-t border-neutral-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <span className={`
                    inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                    ${isCompleted 
                      ? 'bg-green-50 text-green-600' 
                      : isProcessing 
                        ? 'bg-blue-50 text-blue-600' 
                        : 'bg-red-50 text-red-600'
                    }
                  `}>
                    {isCompleted 
                      ? 'Completed' 
                      : isProcessing 
                        ? 'Processing' 
                        : 'Failed'
                    }
                  </span>
                </div>
                
                <div className="text-sm text-neutral-500">
                  Original file: {project.originalFile.split('/').pop()}
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6 mb-6">
            <h2 className="text-lg font-semibold text-neutral-800 mb-4">Project Details</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <p className="text-sm font-medium text-neutral-500 mb-1">Project Name</p>
                <p className="text-neutral-800">{project.name}</p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-neutral-500 mb-1">Created</p>
                <p className="text-neutral-800">
                  {new Date(project.createdAt).toLocaleDateString()} at {new Date(project.createdAt).toLocaleTimeString()}
                </p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-neutral-500 mb-1">Status</p>
                <p className="text-neutral-800">{
                  isCompleted 
                    ? 'Completed' 
                    : isProcessing 
                      ? 'Processing' 
                      : 'Failed'
                }</p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-neutral-500 mb-1">Last Updated</p>
                <p className="text-neutral-800">
                  {new Date(project.updatedAt).toLocaleDateString()} at {new Date(project.updatedAt).toLocaleTimeString()}
                </p>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
