import Sidebar from "@/components/layout/sidebar";
import Navbar from "@/components/layout/navbar";
import SubscriptionCard from "@/components/subscription-card";
import { useAuth } from "@/hooks/use-auth";
import { subscriptionPlans, planLimits } from "@shared/schema";

export default function Subscription() {
  const { user } = useAuth();

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        
        <main className="flex-1 overflow-auto p-4 md:p-6 bg-neutral-50">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-neutral-800">Subscription Plans</h1>
            <p className="text-neutral-600 mt-1">Choose the plan that works best for you</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <SubscriptionCard
              title="Monthly"
              price={15}
              period="month"
              features={[
                `${planLimits[subscriptionPlans.MONTHLY]} conversions per day`,
                "Advanced editing tools",
                "Priority processing",
                "AI guidance"
              ]}
              planId={subscriptionPlans.MONTHLY}
            />
            
            <SubscriptionCard
              title="Half-Yearly"
              price={70}
              period="6 months"
              features={[
                `${planLimits[subscriptionPlans.HALF_YEARLY]} conversions per day`,
                "Advanced editing tools",
                "Priority processing",
                "AI guidance",
                "Email support"
              ]}
              popular={true}
              savings="Save $20"
              planId={subscriptionPlans.HALF_YEARLY}
            />
            
            <SubscriptionCard
              title="Yearly"
              price={120}
              period="year"
              features={[
                `${planLimits[subscriptionPlans.YEARLY]} conversions per day`,
                "Advanced editing tools",
                "Priority processing",
                "AI guidance",
                "Priority email support",
                "Offline mode"
              ]}
              savings="Save $60"
              planId={subscriptionPlans.YEARLY}
            />
          </div>
          
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6 mb-8">
            <h2 className="text-lg font-semibold text-neutral-800 mb-4">Payment Information</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-neutral-700 mb-2">Bank Transfer Details</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                    <p className="text-sm text-neutral-600 mb-1">Bank Name</p>
                    <p className="font-medium text-neutral-800">Bank Central Asia</p>
                  </div>
                  <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                    <p className="text-sm text-neutral-600 mb-1">Branch</p>
                    <p className="font-medium text-neutral-800">Green Garden Jakarta City</p>
                  </div>
                  <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                    <p className="text-sm text-neutral-600 mb-1">Account Number</p>
                    <p className="font-medium text-neutral-800">2533599249</p>
                  </div>
                  <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                    <p className="text-sm text-neutral-600 mb-1">Account Name</p>
                    <p className="font-medium text-neutral-800">Glorio Theopil Petra</p>
                  </div>
                  <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                    <p className="text-sm text-neutral-600 mb-1">Swift Code</p>
                    <p className="font-medium text-neutral-800">CENAIDJA</p>
                  </div>
                  <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                    <p className="text-sm text-neutral-600 mb-1">Country</p>
                    <p className="font-medium text-neutral-800">Indonesia</p>
                  </div>
                </div>
              </div>
              
              <div className="p-4 bg-amber-50 rounded-lg border border-amber-100">
                <h3 className="font-medium text-amber-800 mb-2">Payment Instructions</h3>
                <ol className="list-decimal list-inside text-sm text-amber-700 space-y-2">
                  <li>Choose your subscription plan above</li>
                  <li>Make a bank transfer to the account details provided</li>
                  <li>Use your username as payment reference</li>
                  <li>After payment, your account will be upgraded within 24 hours</li>
                </ol>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <h2 className="text-lg font-semibold text-neutral-800 mb-4">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-neutral-800 mb-1">How do I upgrade my account?</h3>
                <p className="text-neutral-600 text-sm">Select your preferred plan, make a bank transfer, and your account will be upgraded within 24 hours.</p>
              </div>
              <div>
                <h3 className="font-medium text-neutral-800 mb-1">Can I change my plan later?</h3>
                <p className="text-neutral-600 text-sm">Yes, you can upgrade or downgrade your plan at any time.</p>
              </div>
              <div>
                <h3 className="font-medium text-neutral-800 mb-1">What's included in the free trial?</h3>
                <p className="text-neutral-600 text-sm">The free trial allows you to create one 3D model from a 2D layout to test the service.</p>
              </div>
              <div>
                <h3 className="font-medium text-neutral-800 mb-1">How many conversions do I get per day?</h3>
                <p className="text-neutral-600 text-sm">All paid plans include 5 conversions per day.</p>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
