import { useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import Navbar from "@/components/layout/navbar";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("account");
  const [language, setLanguage] = useState("en");
  const [email, setEmail] = useState(user?.email || "");
  const [notifications, setNotifications] = useState(true);

  const handleSaveProfile = () => {
    // In a real app, this would update the user profile
    toast({
      title: "Profile Updated",
      description: "Your profile has been updated successfully.",
    });
  };

  const handleSavePreferences = () => {
    // In a real app, this would update user preferences
    toast({
      title: "Preferences Saved",
      description: "Your preferences have been saved successfully.",
    });
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        
        <main className="flex-1 overflow-auto p-4 md:p-6 bg-neutral-50">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-neutral-800">Settings</h1>
            <p className="text-neutral-600 mt-1">Manage your account and preferences</p>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <div className="border-b border-neutral-200">
                <TabsList className="p-0 border-0 bg-transparent">
                  <TabsTrigger 
                    value="account" 
                    className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
                  >
                    Account
                  </TabsTrigger>
                  <TabsTrigger 
                    value="preferences" 
                    className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
                  >
                    Preferences
                  </TabsTrigger>
                  <TabsTrigger 
                    value="billing" 
                    className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
                  >
                    Billing
                  </TabsTrigger>
                </TabsList>
              </div>
              
              <div className="p-6">
                <TabsContent value="account" className="mt-0">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-neutral-800 mb-4">Account Information</h3>
                      
                      <div className="grid gap-4">
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="username">Username</Label>
                            <Input 
                              id="username" 
                              value={user?.username || ""} 
                              disabled 
                              className="mt-1" 
                            />
                            <p className="text-xs text-neutral-500 mt-1">Cannot be changed</p>
                          </div>
                          
                          <div>
                            <Label htmlFor="email">Email</Label>
                            <Input 
                              id="email" 
                              type="email" 
                              value={email} 
                              onChange={(e) => setEmail(e.target.value)} 
                              className="mt-1" 
                            />
                          </div>
                        </div>
                        
                        <div>
                          <Label htmlFor="current-password">Current Password</Label>
                          <Input 
                            id="current-password" 
                            type="password" 
                            placeholder="Enter current password" 
                            className="mt-1" 
                          />
                        </div>
                        
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="new-password">New Password</Label>
                            <Input 
                              id="new-password" 
                              type="password" 
                              placeholder="Enter new password" 
                              className="mt-1" 
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="confirm-password">Confirm New Password</Label>
                            <Input 
                              id="confirm-password" 
                              type="password" 
                              placeholder="Confirm new password" 
                              className="mt-1" 
                            />
                          </div>
                        </div>
                      </div>
                      
                      <Button onClick={handleSaveProfile} className="mt-6">
                        Save Changes
                      </Button>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="preferences" className="mt-0">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-neutral-800 mb-4">Application Preferences</h3>
                      
                      <div className="grid gap-4">
                        <div>
                          <Label htmlFor="language">Language</Label>
                          <Select value={language} onValueChange={setLanguage}>
                            <SelectTrigger id="language" className="mt-1">
                              <SelectValue placeholder="Select language" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="en">English</SelectItem>
                              <SelectItem value="es">Español</SelectItem>
                              <SelectItem value="fr">Français</SelectItem>
                              <SelectItem value="de">Deutsch</SelectItem>
                              <SelectItem value="zh">中文</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="notifications"
                            checked={notifications}
                            onChange={(e) => setNotifications(e.target.checked)}
                            className="h-4 w-4 rounded border-neutral-300 text-primary focus:ring-primary"
                          />
                          <Label htmlFor="notifications" className="text-sm font-medium text-neutral-700">
                            Enable email notifications
                          </Label>
                        </div>
                      </div>
                      
                      <Button onClick={handleSavePreferences} className="mt-6">
                        Save Preferences
                      </Button>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="billing" className="mt-0">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-neutral-800 mb-4">Subscription Information</h3>
                      
                      <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200 mb-6">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-sm font-medium text-neutral-700">Current Plan</p>
                            <p className="text-lg font-semibold text-neutral-800 mt-1">
                              {user?.plan === "free_trial" ? "Free Trial" : 
                               user?.plan === "monthly" ? "Monthly ($15/month)" :
                               user?.plan === "half_yearly" ? "Half-Yearly ($70/6 months)" :
                               user?.plan === "yearly" ? "Yearly ($120/year)" : "None"}
                            </p>
                          </div>
                          
                          <Button variant="outline" asChild>
                            <a href="/subscription">Manage Subscription</a>
                          </Button>
                        </div>
                      </div>
                      
                      <h3 className="text-lg font-medium text-neutral-800 mb-4">Payment Information</h3>
                      
                      <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200 text-center">
                        <p className="text-neutral-600">
                          Payment is handled through bank transfer. Please visit the subscription page to see payment details.
                        </p>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </div>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}
