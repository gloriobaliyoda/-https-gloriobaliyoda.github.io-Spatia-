import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { subscriptionPlans, planLimits } from "@shared/schema";
import { AlertCircle, Loader2 } from "lucide-react";
import Sidebar from "@/components/layout/sidebar";
import Navbar from "@/components/layout/navbar";
import FileUpload from "@/components/file-upload";
import SpeechRecognition from "@/components/speech-recognition";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function NewConversion() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState("");
  const [projectName, setProjectName] = useState("");
  const [commandInput, setCommandInput] = useState("");
  
  // First mutation: Create project metadata
  const createProjectMutation = useMutation({
    mutationFn: async (name: string) => {
      // Create the project with name and originalFile
      const response = await apiRequest("POST", "/api/projects", { 
        name, 
        originalFile: fileName || "untitled.jpg" 
      });
      return await response.json();
    },
    onSuccess: (project) => {
      // After creating the project, upload the file if available
      if (file && fileName) {
        uploadFileMutation.mutate({ projectId: project.id, file, fileName });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create project",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Second mutation: Upload the file for processing
  const uploadFileMutation = useMutation({
    mutationFn: async ({ projectId, file, fileName }: { projectId: number, file: File, fileName: string }) => {
      // Prepare form data for file upload
      const formData = new FormData();
      formData.append("file", file);
      
      // Upload the file to the project using apiRequest
      const response = await apiRequest(
        "POST", 
        `/api/projects/${projectId}/upload`, 
        formData,
        true // Pass true for FormData
      );
      
      return await response.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "AI Conversion started",
        description: "Your 2D layout is being processed into a 3D model using advanced AI",
      });
      navigate(`/view-project/${variables.projectId}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Conversion failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleVoiceCommand = (transcript: string) => {
    toast({
      title: "Voice command received",
      description: transcript,
    });
    
    const lowerTranscript = transcript.toLowerCase();
    
    if (lowerTranscript.includes("upload") || lowerTranscript.includes("select file")) {
      document.getElementById("fileUploadButton")?.click();
    } else if (lowerTranscript.includes("convert") || lowerTranscript.includes("create model")) {
      handleSubmit();
    } else if (lowerTranscript.includes("name") && lowerTranscript.includes("project")) {
      // Extract project name from voice command
      const nameMatch = lowerTranscript.match(/name (?:the|this|) project (.*)/i);
      if (nameMatch && nameMatch[1]) {
        setProjectName(nameMatch[1]);
      }
    } else {
      setCommandInput(transcript);
    }
  };

  const handleFileSelected = (selectedFile: File, name: string) => {
    setFile(selectedFile);
    setFileName(name);
    
    if (!projectName) {
      // Generate project name from file name
      const baseName = selectedFile.name.split('.')[0];
      setProjectName(baseName.replace(/[-_]/g, ' '));
    }
  };

  const handleSubmit = () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please upload a 2D layout file",
        variant: "destructive",
      });
      return;
    }

    if (!projectName.trim()) {
      toast({
        title: "Project name required",
        description: "Please enter a name for your project",
        variant: "destructive",
      });
      return;
    }

    // Only pass the name to create the project first
    createProjectMutation.mutate(projectName);
  };

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!commandInput.trim()) return;
    
    // Process the text command
    const lowerCommand = commandInput.toLowerCase();
    
    if (lowerCommand.includes("convert") || lowerCommand.includes("create model")) {
      handleSubmit();
    } else if (lowerCommand.includes("name") && lowerCommand.includes("project")) {
      // Extract project name from text command
      const nameMatch = lowerCommand.match(/name (?:the|this|) project (.*)/i);
      if (nameMatch && nameMatch[1]) {
        setProjectName(nameMatch[1]);
      }
    }
    
    // Clear the input after processing
    setCommandInput("");
  };

  // Check if user has reached their limit
  const hasReachedLimit = user?.plan === subscriptionPlans.FREE_TRIAL && 
                          user?.conversionsUsed >= planLimits[subscriptionPlans.FREE_TRIAL];

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        
        <main className="flex-1 overflow-auto p-4 md:p-6 bg-neutral-50">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-neutral-800">Create New 3D Model</h1>
            <p className="text-neutral-600 mt-1">Upload your 2D layout and convert it to a 3D model</p>
          </div>
          
          {hasReachedLimit && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Free trial limit reached</AlertTitle>
              <AlertDescription>
                You have reached your free trial limit. Please upgrade to continue creating 3D models.
              </AlertDescription>
              <Button variant="outline" className="mt-2" onClick={() => navigate("/subscription")}>
                Upgrade Now
              </Button>
            </Alert>
          )}
          
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 mb-8 overflow-hidden">
            <div className="p-6">
              <div className="mb-6">
                <Label htmlFor="projectName">Project Name</Label>
                <Input
                  id="projectName"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  placeholder="Enter a name for your project"
                  className="mt-1"
                />
              </div>
              
              <FileUpload 
                onFileSelected={handleFileSelected} 
              />
              
              <div className="mt-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-center space-x-3">
                  <SpeechRecognition onResult={handleVoiceCommand} />
                  <div>
                    <p className="text-sm font-medium text-neutral-700">Voice Commands</p>
                    <p className="text-xs text-neutral-500">Say "Upload file" or "Create model"</p>
                  </div>
                </div>
                
                <form onSubmit={handleCommandSubmit} className="relative flex-1 max-w-sm">
                  <Input 
                    type="text" 
                    placeholder="Type a command..." 
                    value={commandInput}
                    onChange={(e) => setCommandInput(e.target.value)}
                    className="pr-10"
                  />
                  <Button 
                    type="submit"
                    variant="ghost" 
                    size="icon"
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-primary"
                  >
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m22 2-7 20-4-9-9-4Z" />
                      <path d="M22 2 11 13" />
                    </svg>
                  </Button>
                </form>
              </div>
              
              <div className="mt-6">
                <Button 
                  onClick={handleSubmit} 
                  disabled={!file || !projectName.trim() || createProjectMutation.isPending || hasReachedLimit}
                  className="w-full sm:w-auto"
                  size="lg"
                >
                  {createProjectMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Converting...
                    </>
                  ) : (
                    "Convert to 3D Model"
                  )}
                </Button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
