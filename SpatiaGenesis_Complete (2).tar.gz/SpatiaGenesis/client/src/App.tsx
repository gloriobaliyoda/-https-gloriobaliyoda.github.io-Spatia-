import { Switch, Route } from "wouter";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import AuthPage from "@/pages/auth-page";
import NewConversion from "@/pages/new-conversion";
import Projects from "@/pages/projects";
import ViewProject from "@/pages/view-project";
import Settings from "@/pages/settings";
import Subscription from "@/pages/subscription";
import { ProtectedRoute } from "./lib/protected-route";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/new-conversion" component={NewConversion} />
      <ProtectedRoute path="/projects" component={Projects} />
      <ProtectedRoute path="/view-project/:id" component={ViewProject} />
      <ProtectedRoute path="/settings" component={Settings} />
      <ProtectedRoute path="/subscription" component={Subscription} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return <Router />;
}

export default App;
