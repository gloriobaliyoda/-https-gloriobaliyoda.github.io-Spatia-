# SpatiaGenesis

SpatiaGenesis is a cutting-edge AI-powered web application that transforms 2D layouts into 3D models using advanced machine learning and voice interaction technologies.

## Features

- **2D to 3D Conversion**: Convert various 2D layouts, blueprints, and sketches into detailed 3D models
- **AI-Powered Design**: Utilizes OpenAI for intelligent analysis and conversion
- **Role-Optimized Processing**: Enhanced for designers, engineers, customer service, and troubleshooting
- **Realistic Rendering**: Integration with Blender and SketchUp for high-quality 3D visualizations
- **Voice Commands**: Hands-free interaction through speech recognition
- **Subscription Management**: Tiered subscription plans with different features and limits
- **User Authentication**: Secure login and registration system
- **Projects Management**: Create, view, and manage conversion projects

## Technology Stack

- **Frontend**: React, TailwindCSS, Three.js for 3D rendering
- **Backend**: Node.js with Express
- **Authentication**: Passport.js with session-based auth
- **3D Processing**: OpenAI API, Blender, SketchUp integration
- **Storage**: In-memory (development) or PostgreSQL database (production)

## Installation

1. Extract the SpatiaGenesis.tar.gz archive
2. Install dependencies:
   ```
   npm install
   ```
3. Start the development server:
   ```
   npm run dev
   ```

## Default Login

For development and testing, a default admin user is available:
- Username: `admin`
- Password: `admin123`

## Environment Variables

The application requires the following environment variables:
- `OPENAI_API_KEY`: Your OpenAI API key (for AI-powered conversions)

## Project Structure

- `/client`: React frontend application
- `/server`: Node.js backend services
- `/shared`: Shared types and schemas
- `/public`: Static assets and generated models

## Key Services

### OpenAI Integration
Multi-perspective AI analysis optimized for different professional roles:
- Designer perspective for aesthetics and spatial relationships
- Engineering perspective for structural integrity and physical properties
- Customer service perspective for user experience and client needs
- Troubleshooting perspective for performance optimization

### Blender Integration
Advanced 3D modeling and animation capabilities:
- Process 2D layouts into detailed 3D models with realistic materials
- Create animations with custom duration and style settings
- Support for various file formats and export options

### SketchUp Integration
Architectural-focused 3D modeling:
- Convert 2D architectural drawings to 3D models
- Apply different architectural styles and materials
- Generate walkthrough animations for virtual tours

### Enhanced Conversion Pipeline
Intelligent workflow selection based on file type:
- Architectural files processed through SketchUp
- Design files and images processed through Blender
- General files processed through OpenAI
- Combined multi-tool approach for optimal results

## License

All rights reserved. This project is proprietary software.