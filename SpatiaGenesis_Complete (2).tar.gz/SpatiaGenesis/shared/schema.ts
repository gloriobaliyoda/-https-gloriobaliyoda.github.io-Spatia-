import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  plan: text("plan").notNull().default("free_trial"),
  conversionsUsed: integer("conversions_used").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  status: text("status").notNull().default("processing"), // processing, completed, failed
  originalFile: text("original_file").notNull(),
  modelFile: text("model_file"),
  thumbnailFile: text("thumbnail_file"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
});

export const insertProjectSchema = createInsertSchema(projects).pick({
  name: true,
  originalFile: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export type LoginData = z.infer<typeof loginSchema>;

export const subscriptionPlans = {
  FREE_TRIAL: "free_trial",
  MONTHLY: "monthly",
  HALF_YEARLY: "half_yearly",
  YEARLY: "yearly",
};

export const planPrices = {
  [subscriptionPlans.MONTHLY]: 15,
  [subscriptionPlans.HALF_YEARLY]: 70,
  [subscriptionPlans.YEARLY]: 120,
};

export const planLimits = {
  [subscriptionPlans.FREE_TRIAL]: 1,
  [subscriptionPlans.MONTHLY]: 5,
  [subscriptionPlans.HALF_YEARLY]: 5,
  [subscriptionPlans.YEARLY]: 5,
};
